/*! grafana - v1.7.0 - 2014-08-11
 * Copyright (c) 2014 Torkel Ödegaard; Licensed Apache License */

define([],function(){describe("graphiteTargetCtrl",function(){var a;beforeEach(module("grafana.services")),beforeEach(module(function(a){a.value("filterSrv",{})})),beforeEach(inject(function(b,c){a=b({$scope:c.$new()})})),describe("init",function(){beforeEach(function(){})})})});