/*! grafana - v1.5.4 - 2014-05-13
 * Copyright (c) 2014 Torkel Ödegaard; Licensed Apache License */

define([],function(){describe("graphiteTargetCtrl",function(){var a;beforeEach(module("kibana.services")),beforeEach(module(function(a){a.value("filterSrv",{})})),beforeEach(inject(function(b,c){a=b({$scope:c.$new()})})),describe("init",function(){beforeEach(function(){})})})});